<?php
function conexion(){ 
$servidor="localhost";
$usuario="root";
$password="";
$bd= "login";

$conexion = mysqli_connect ($servidor, $usuario, $password, $bd);
if(!$conexion){
die("error al conectar la base de datos de la pagina".mysqli_connect_errno());

}
else{
    echo "conexion exitosa";
}
}
conexion();
?>