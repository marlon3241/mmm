
<?php
if($_POST){
  header('Location:inicio.php');


}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Administrador</title>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  

</head>
  <body>

  Sitio web

  <nav class="navbar navbar-expand-lg navbar-blak bg-primary">
    <ul class="nav navbar-nav">

      <li class="nav-item">
        <a class="nav-link" href="#">METABUSCADOR</a>
</li>

<li class="nav-item">
        <a class="nav-link" href="#">INICIO</a>
</li>

<li class="nav-item">
        <a class="nav-link" href="#">PUBLICIDAD</a>
</li>


<li class="nav-item">
        <a class="nav-link" href="#">MENU</a>
</li>




    </ul>
</nav>


   <div class="container">
       <div class="row">

       <div class="jumbotron">
        <hl class="display-3">Jumbo heading</hl>
        <p class="lead">Jumbo helper text</p>
        <hr class="my-2"> 
        <p>More info</p>
        <p class="lead">
        <a class="btn btn-primary btn-lg" href="Jumbo action link" role="button";>
        
      </p>
</div>

           
       </div>
           <div class="col-md-4">
           <br/><br/><br/><br/><br/><br/>
           <div class="card">
               <div class="card-header">
                   Login
               </div>
               <div class="card-body">

                 <form method="POST">

                 <div class = "form-group">
                 <label >Usuario</label>
                 <input type="text" class="form-control" name="usuario" placeholder="Ingresa tu Usuario">
                 </div>
                 
                 <div class="form-group">
                 <label >Contraseña:</label>
                 <input type="password" class="form-control" name="contraseña" placeholder="Ingresa tu Contraseña">
                 </div>
                 <button type="submit" class="btn btn-primary">Ingresar</button>
                


                 </form>

                 
                  

               </div>
              
           </div>
               
           </div>
           
       </div>
   </div>

  </body>
</html>