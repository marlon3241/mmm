<?php include("template/cabecera.php");?>


<div class="jumbotron">
    <h1 class="display-4">NOSOTROS</h1>
    <p class="lead">(BIENVENIDO A CONOCER NUESTRO EQUIPO DE TRABAJO METABUSCADOR TEC)</p>
   
    <hr class="my-2">
     <p class="lead">->NOYOLA LARA KAREN LISETTE<-</p>

     <hr class="my-2">
     <p class="lead">->LOPEZ HERNANDEZ JESUS ADRIAN<-</p>

     <hr class="my-2">
     <p class="lead">->HERNANDEZ REYES DULCE ITZEL<-</p>

     <hr class="my-2">
     <p class="lead">->JUAREZ JUAREZ CRISTHOFER JESUS<-</p>

     <hr class="my-2">
     <p class="lead">->LOPEZ GRAJEDA GUSTAVO GABINO<-</p>

 </div>
 
 <div class="jumbotron">
    <h4 class="display-6">"LA EDUCACION ES EL ARMA MAS PODEROSA PARA CAMBIAR AL MUNDO"</h4>
    <p class="lead">Queremos llegar a ser los mejores y con tu confianza, sabemos que lo lograremos </p>
   
    
 </div>

<?php include("template/pie.php"); ?>
