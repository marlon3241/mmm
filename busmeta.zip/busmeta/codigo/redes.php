<?php include("template/cabecera.php");?>


<div class="jumbotron">
    <h1 class="display-4">INSTITUCIONES</h1>
    <p class="lead">(TECNM)</p>
   
    <hr class="my-2">
     <p class="lead"></p> <a name="" id="" class="btn btn-primary" href="informatica.php" role="button">PLANTEL IZTAPALAPA III</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL TLAHUAC</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL TLALPAN</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL CHURUBUSCO</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL SANTA FE</a>

 </div>
 
    
 </div>

 <div class="jumbotron">

    <p class="lead">(IPN)</p>
   
    <hr class="my-2">
     <p class="lead"></p> <a name="" id="" class="btn btn-primary" href="informatica.php" role="button">PLANTEL TULTITLAN</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL ERMITA</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL ZACATENCO</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL UPIICSA</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL SANTA FE</a>

 </div>
 
    
 </div>

<?php include("template/pie.php"); ?>
