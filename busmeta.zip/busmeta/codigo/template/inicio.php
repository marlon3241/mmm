<html>
<head>
<body>
  <style>
img.btn-whatsapp {
display: block !important;
position: fixed;
z-index: 9999999;
bottom: 20px;
right: 20px;
cursor: pointer;
border-radius:100px !important;
}
img.btn-whatsapp:hover{
border-radius:100px !important;
-webkit-box-shadow: 0px 0px 15px 0px rgba(7,94,84,1); 
-moz-box-shadow: 0px 0px 15px 0px rgba(7,94,84,1);
box-shadow: 0px 0px 15px 0px rgba(7,94,84,1);
transition-duration: 1s;
} 
</style>
</head>

<img class="btn-whatsapp" src="https://api.whatsapp.com/send?phone=525582639781" width="64" height="64" alt="Whatsapp" onclick="window.location.href='https://wa.me/+525582639781?text=Hola!%20Estoy%20interesado%20en%20un%20pedido'">
<?php include('template/cabecera2.php'); ?>
               <div class="col-md-12">
               <div class="jumbotron">
                      <h1 class="display-3">BAR KARAOKE "THE SQUAD"</h1>
                      <p class="lead">VEN Y DISFRUTA DE LAS MEJORES BEBIDAS Y AMBIENTE DE LA ZONA, ESTAMOS COMPROMETIDOS CONTIGO.</p>
                      <hr class="my-2">
                      <p>Mas informacion contactanos por redes sociales</p>
                      <p class="lead">
                          <a class="btn btn-primary btn-lg" href="Jumbo action link" role="button">Facebook: Bazar L.N.L:</a>
                      </p>
             </div>
    
            </div>

<?php include('template/pie2.php'); ?>
</body>
</html>

















