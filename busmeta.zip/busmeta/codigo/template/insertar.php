<?php

$servidor="localhost";
$usuario="root";
$password="";
$bd= "login";
$conexion = mysqli_connect ($servidor, $usuario, $password, $bd);

if(isset($_POST['nombre']) || isset($_POST['telefono']) || isset($_POST['correo']) || isset($_POST['contraseña'])){
$nombre= $_POST ["nombre"];
$telefono = $_POST ["telefono"];
$correo = $_POST ["correo"];
$contraseña = $_POST ["contraseña"];


}



if(!$conexion){
 echo "no se ha podido conectar con el servidor";
  }

  else{
      echo "<b><h3>conexion exitosa</h3></b>";
  }
  
$db = mysqli_select_db($conexion, $bd);

if(!$bd)
{
echo "no se ha podido encotrar la tabla";
}
else
{
echo "<h3>Tabla seleccionada:</h3>";
}

if(isset($_POST['nombre']) || isset($_POST['telefono']) || isset($_POST['correo']) || isset($_POST['contraseña'])){

  $instruccion_SQL = "INSERT INTO usuarios(usunombre,usunumtel,usucorreo,usuclave) 
VALUES ('$nombre','$telefono','$correo','$contraseña')";
$resultado= mysqli_query($conexion,$instruccion_SQL);
  }
  





$consulta = "SELECT * FROM usuarios";
$result = mysqli_query($conexion,$consulta);
if(!$result)
{
  echo "no se ha podido realizar la consulta";
}
echo "<table>";
echo "<tr>";
echo "<th><h1>Nombre</th></h1>";
echo "<th><h1>Telefono</th></h1>";
echo "<th><h1>Correo</th></h1>";
echo "<th><h1>Contraseña</th></h1>";
echo "</tr>";

while($colum = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<th><h2>" . $colum ['usunombre']. "</td></h2>";
echo "<th><h2>" . $colum ['usunumtel']. "</td></h2>";
echo "<th><h2>" . $colum ['usucorreo']. "</td></h2>";
echo "<th><h2>" . $colum ['usuclave']. "</td></h2>";
echo "</tr>";
}
echo "</table>";
mysqli_close($conexion);

echo '<a href="index.php"> volver atras </a>';
?>



